module.exports = {
   Perms: [
      { permissions: [roller.clownHammer], commands: "vip", roles: roller.vipRol },
      { permissions: [roller.clownHammer], commands: "müzisyen", roles: "" },
      { permissions: [roller.clownHammer], commands: "Vokalist", roles: "" },
      { permissions: [roller.clownHammer], commands: "dj", roles: "" }
   ]
}
